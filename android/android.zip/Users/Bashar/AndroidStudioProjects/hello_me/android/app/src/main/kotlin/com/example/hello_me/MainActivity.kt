package com.example.hello_me

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
